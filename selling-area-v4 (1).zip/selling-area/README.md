# Selling Area

App React standalone — non richiede base44.
I dati vengono salvati nel localStorage del browser.

## Come avviare in locale

```bash
npm install
npm run dev
```

## Come pubblicare gratis su Vercel

1. Vai su https://vercel.com e crea un account gratuito
2. Installa Vercel CLI: `npm i -g vercel`
3. Dalla cartella del progetto: `vercel`
4. Segui le istruzioni — in 2 minuti l'app è online!

## Oppure su Netlify

1. Vai su https://netlify.com
2. Trascina la cartella `dist` (dopo `npm run build`) nel sito
3. Done!

## Note importanti

- I dati sono salvati nel **localStorage** del browser
- Non c'è autenticazione — chiunque può accedere alle pagine admin
- Le immagini vengono salvate come base64 nel localStorage (max ~2MB per immagine)
- Per il PayPal/IBAN nel CheckoutDialog, modifica `src/components/shop/CheckoutDialog.jsx`
