import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'

// Always use dark mode to match the original app design
document.documentElement.classList.add('dark');

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
