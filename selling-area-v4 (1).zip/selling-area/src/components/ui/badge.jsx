import { cn } from "@/lib/utils"
export function Badge({ className, variant="default", ...props }) {
  return <div className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors", variant==="default" && "border-transparent bg-primary text-primary-foreground", className)} {...props} />
}
