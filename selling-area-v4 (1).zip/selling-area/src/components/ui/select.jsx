import { useState, useRef, useEffect } from "react"
import { ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"

export function Select({ value, onValueChange, children, required }) {
  const [open, setOpen] = useState(false)
  return <div className="relative" data-value={value} data-required={required}>{React.Children.map(children, c => React.cloneElement(c, { open, setOpen, value, onValueChange }))}</div>
}
import React from "react"
export function SelectTrigger({ children, open, setOpen, className }) {
  return <button type="button" onClick={() => setOpen(!open)} className={cn("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className)}>{children}<ChevronDown className="h-4 w-4 opacity-50" /></button>
}
export function SelectValue({ placeholder, value }) { return <span className={value ? "" : "text-muted-foreground"}>{value || placeholder}</span> }
export function SelectContent({ children, open, setOpen, onValueChange, value }) {
  const ref = useRef()
  useEffect(() => {
    if (!open) return
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [open, setOpen])
  if (!open) return null
  return <div ref={ref} className="absolute z-50 min-w-[8rem] w-full overflow-hidden rounded-md border bg-card text-card-foreground shadow-md top-full mt-1">{React.Children.map(children, c => React.cloneElement(c, { onValueChange, setOpen, selectedValue: value }))}</div>
}
export function SelectItem({ value, children, onValueChange, setOpen, selectedValue }) {
  return <div onClick={() => { onValueChange(value); setOpen(false) }} className={cn("relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 px-2 text-sm outline-none hover:bg-accent hover:text-accent-foreground", selectedValue === value && "bg-accent")}>{children}</div>
}
