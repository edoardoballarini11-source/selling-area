import { cn } from "@/lib/utils"
import { X } from "lucide-react"
export function Dialog({ open, onOpenChange, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/50" onClick={() => onOpenChange(false)} />
      <div className="relative z-50 w-full max-w-lg">{children}</div>
    </div>
  )
}
export function DialogContent({ className, children }) {
  return <div className={cn("bg-card border border-border rounded-2xl p-6 shadow-xl mx-4", className)}>{children}</div>
}
export function DialogHeader({ children }) { return <div className="flex flex-col space-y-1.5 mb-4">{children}</div> }
export function DialogTitle({ className, children }) { return <h2 className={cn("text-lg font-semibold leading-none tracking-tight", className)}>{children}</h2> }
export function DialogFooter({ children }) { return <div className="flex justify-end gap-3 mt-4">{children}</div> }
