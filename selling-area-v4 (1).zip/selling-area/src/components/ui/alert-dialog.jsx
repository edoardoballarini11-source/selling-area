import { cn } from "@/lib/utils"
import { Button } from "./button"
export function AlertDialog({ open, onOpenChange, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/50" onClick={() => onOpenChange(false)} />
      <div className="relative z-50 w-full max-w-md mx-4">{children}</div>
    </div>
  )
}
export function AlertDialogContent({ children }) { return <div className="bg-card border border-border rounded-2xl p-6 shadow-xl">{children}</div> }
export function AlertDialogHeader({ children }) { return <div className="mb-4">{children}</div> }
export function AlertDialogTitle({ children }) { return <h2 className="text-lg font-semibold">{children}</h2> }
export function AlertDialogDescription({ children }) { return <p className="text-sm text-muted-foreground mt-2">{children}</p> }
export function AlertDialogFooter({ children }) { return <div className="flex justify-end gap-3 mt-6">{children}</div> }
export function AlertDialogAction({ children, onClick, className }) { return <Button onClick={onClick} className={className}>{children}</Button> }
export function AlertDialogCancel({ children, onClick }) { return <Button variant="outline" onClick={onClick}>{children}</Button> }
