export default function UserNotRegisteredError() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <div className="max-w-md w-full p-8 bg-white rounded-lg shadow-lg border">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Access Restricted</h1>
        <p className="text-slate-600">You are not registered to use this application.</p>
      </div>
    </div>
  );
}
