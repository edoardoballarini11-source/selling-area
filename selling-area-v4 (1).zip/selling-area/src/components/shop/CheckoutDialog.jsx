import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, Loader2, ShoppingCart, CreditCard, Copy } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
const PAYPAL_EMAIL = "tuaemail@paypal.com";
const IBAN = "IT00 X000 0000 0000 0000 0000 000";
export default function CheckoutDialog({ open, onOpenChange, item }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [step, setStep] = useState("form");
  const [form, setForm] = useState({ nome: "", cognome: "", indirizzo: "", telefono: "" });
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(null);
  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));
  const handleFormSubmit = (e) => { e.preventDefault(); setStep("payment"); };
  const handlePaid = async () => {
    setLoading(true);
    await base44.entities.Item.update(item.id, { status: "pending_payment", buyer_name: form.nome, buyer_surname: form.cognome, buyer_address: form.indirizzo, buyer_phone: form.telefono });
    queryClient.invalidateQueries({ queryKey: ["shop-items"] });
    queryClient.invalidateQueries({ queryKey: ["item", item.id] });
    queryClient.invalidateQueries({ queryKey: ["items"] });
    setLoading(false); setStep("success");
  };
  const handleClose = () => { if (step === "success") navigate("/"); onOpenChange(false); setTimeout(() => { setStep("form"); setForm({ nome: "", cognome: "", indirizzo: "", telefono: "" }); }, 300); };
  const copyToClipboard = (text, key) => { navigator.clipboard.writeText(text); setCopied(key); setTimeout(() => setCopied(null), 2000); };
  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        {step === "form" && (<>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><ShoppingCart className="h-5 w-5 text-primary" />Dati di Spedizione</DialogTitle><p className="text-sm text-muted-foreground mt-1"><span className="font-semibold text-foreground">{item?.name}</span>{item?.sell_price && <span className="ml-2 text-primary font-bold">€{item.sell_price.toFixed(2)}</span>}</p></DialogHeader>
          <form onSubmit={handleFormSubmit} className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-3"><div className="space-y-1.5"><Label>Nome *</Label><Input required value={form.nome} onChange={(e) => update("nome", e.target.value)} placeholder="Mario" /></div><div className="space-y-1.5"><Label>Cognome *</Label><Input required value={form.cognome} onChange={(e) => update("cognome", e.target.value)} placeholder="Rossi" /></div></div>
            <div className="space-y-1.5"><Label>Indirizzo di Spedizione *</Label><Input required value={form.indirizzo} onChange={(e) => update("indirizzo", e.target.value)} placeholder="Via Roma 1, 20100 Milano" /></div>
            <div className="space-y-1.5"><Label>Numero di Telefono *</Label><Input required type="tel" value={form.telefono} onChange={(e) => update("telefono", e.target.value)} placeholder="+39 333 123 4567" /></div>
            <div className="flex gap-3 pt-2"><Button type="button" variant="outline" className="flex-1" onClick={handleClose}>Annulla</Button><Button type="submit" className="flex-1">Procedi →</Button></div>
          </form>
        </>)}
        {step === "payment" && (
          <div className="space-y-5">
            <DialogHeader><DialogTitle className="flex items-center gap-2"><CreditCard className="h-5 w-5 text-primary" />Completa il Pagamento</DialogTitle></DialogHeader>
            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4 text-sm space-y-3">
              <p className="font-semibold text-foreground">Invia <span className="text-primary font-bold">€{item?.sell_price?.toFixed(2)}</span> tramite:</p>
              <div className="space-y-2"><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">PayPal</p><div className="flex items-center justify-between bg-card border border-border rounded-xl px-3 py-2 gap-2"><span className="font-mono text-sm">{PAYPAL_EMAIL}</span><button onClick={() => copyToClipboard(PAYPAL_EMAIL, "paypal")} className="text-muted-foreground hover:text-foreground">{copied === "paypal" ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}</button></div></div>
              <div className="space-y-2"><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Bonifico (IBAN)</p><div className="flex items-center justify-between bg-card border border-border rounded-xl px-3 py-2 gap-2"><span className="font-mono text-xs">{IBAN}</span><button onClick={() => copyToClipboard(IBAN, "iban")} className="text-muted-foreground hover:text-foreground">{copied === "iban" ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}</button></div></div>
              <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2"><p className="text-xs text-amber-800"><span className="font-semibold">Causale:</span> {item?.name}</p></div>
            </div>
            <div className="flex gap-3"><Button variant="outline" className="flex-1" onClick={() => setStep("form")}>← Indietro</Button><Button className="flex-1" onClick={handlePaid} disabled={loading}>{loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}Ho Pagato ✓</Button></div>
          </div>
        )}
        {step === "success" && (
          <div className="flex flex-col items-center gap-4 py-6 text-center">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
            <DialogTitle className="text-xl font-bold">Grazie!</DialogTitle>
            <p className="text-muted-foreground text-sm">Il tuo ordine è in attesa di verifica del pagamento.</p>
            <Button className="w-full mt-2" onClick={handleClose}>Torna alla vetrina</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
