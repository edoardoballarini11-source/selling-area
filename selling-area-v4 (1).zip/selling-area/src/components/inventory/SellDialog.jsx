import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DollarSign, TrendingUp } from "lucide-react";
export default function SellDialog({ item, open, onOpenChange, onConfirm, isLoading }) {
  const [sellPrice, setSellPrice] = useState("");
  const [sellDate, setSellDate] = useState(new Date().toISOString().split("T")[0]);
  const profit = sellPrice ? (parseFloat(sellPrice) - item?.purchase_price) : 0;
  const handleConfirm = () => { onConfirm({ sell_price: parseFloat(sellPrice), sell_date: sellDate, status: "sold" }); };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle className="font-display text-xl">Vendi {item?.name}</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4">
          <div className="bg-accent/50 rounded-xl p-4 text-sm"><span className="text-muted-foreground">Prezzo di acquisto: </span><span className="font-semibold">€{item?.purchase_price?.toFixed(2)}</span></div>
          <div className="space-y-2"><Label htmlFor="sell-price">Sell Price</Label><div className="relative"><DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="sell-price" type="number" step="0.01" min="0" placeholder="0.00" className="pl-9" value={sellPrice} onChange={(e) => setSellPrice(e.target.value)} /></div></div>
          <div className="space-y-2"><Label htmlFor="sell-date">Sell Date</Label><Input id="sell-date" type="date" value={sellDate} onChange={(e) => setSellDate(e.target.value)} /></div>
          {sellPrice && (<div className="flex items-center gap-2 p-4 rounded-xl bg-accent/50"><TrendingUp className="h-4 w-4 text-accent-foreground" /><span className="text-sm text-muted-foreground">Profitto stimato:</span><span className={`font-bold ${profit >= 0 ? "text-green-600" : "text-red-500"}`}>{profit >= 0 ? "+" : ""}€{profit.toFixed(2)}</span></div>)}
        </div>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button onClick={handleConfirm} disabled={!sellPrice || isLoading}>Confirm Sale</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
