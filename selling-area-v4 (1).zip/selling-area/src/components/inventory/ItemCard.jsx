import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { DollarSign, TrendingUp, TrendingDown, Package } from "lucide-react";
import { cn } from "@/lib/utils";
const categoryLabels = { electronics:"Electronics",clothing:"Clothing",furniture:"Furniture",collectibles:"Collectibles",vehicles:"Vehicles",jewelry:"Jewelry",tools:"Tools",sports:"Sports",books:"Books",other:"Other" };
export default function ItemCard({ item, onSell }) {
  const isSold = item.status === "sold";
  const profit = isSold ? (item.sell_price - item.purchase_price) : null;
  const profitPercent = isSold ? ((profit / item.purchase_price) * 100).toFixed(1) : null;
  return (
    <div className="group bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300">
      <div className="relative h-40 bg-muted overflow-hidden">
        {item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" /> : <div className="w-full h-full flex items-center justify-center"><Package className="h-12 w-12 text-muted-foreground/30" /></div>}
        <Badge className={cn("absolute top-3 right-3 text-xs font-semibold", isSold ? "bg-green-500/90 text-white hover:bg-green-500/90" : "bg-primary/90 text-primary-foreground hover:bg-primary/90")}>{isSold ? "Sold" : "In Stock"}</Badge>
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-2">
          <div><h3 className="font-semibold text-foreground truncate">{item.name}</h3><p className="text-xs text-muted-foreground mt-0.5">{categoryLabels[item.category] || item.category}</p></div>
        </div>
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Acquistato per</span><span className="font-semibold">€{item.purchase_price?.toFixed(2)}</span></div>
          {item.selling_price && !isSold && <div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Prezzo di vendita</span><span className="font-semibold text-primary">€{item.selling_price?.toFixed(2)}</span></div>}
          {isSold && (<>
            <div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Venduto per</span><span className="font-semibold">€{item.sell_price?.toFixed(2)}</span></div>
            <div className="flex items-center justify-between text-sm pt-2 border-t border-border"><span className="text-muted-foreground">Profitto</span>
              <div className="flex items-center gap-1.5">{profit >= 0 ? <TrendingUp className="h-3.5 w-3.5 text-green-500" /> : <TrendingDown className="h-3.5 w-3.5 text-red-500" />}<span className={cn("font-bold", profit >= 0 ? "text-green-600" : "text-red-500")}>{profit >= 0 ? "+" : ""}€{profit?.toFixed(2)} ({profitPercent}%)</span></div>
            </div>
          </>)}
        </div>
        <div className="mt-4 text-xs text-muted-foreground">
          Acquistato {item.purchase_date ? format(new Date(item.purchase_date), "MMM d, yyyy") : ""}
          {item.sell_date && ` · Venduto ${format(new Date(item.sell_date), "MMM d, yyyy")}`}
        </div>
        {!isSold && <div className="mt-4 flex gap-2"><Button size="sm" className="flex-1" onClick={() => onSell(item)}><DollarSign className="h-3.5 w-3.5 mr-1" />Mark as Sold</Button></div>}
      </div>
    </div>
  );
}
