import { format } from "date-fns";
import { Trash2, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
const categoryLabels = { purchase:"Acquisto",sale:"Vendita",shipping:"Spedizione",fee:"Commissione",tax:"Tasse",other:"Altro" };
export default function TransactionList({ transactions, onDelete }) {
  if (transactions.length === 0) return <div className="flex flex-col items-center justify-center py-16 text-center"><p className="text-muted-foreground">Nessuna transazione ancora. Aggiungine una!</p></div>;
  return (
    <div className="space-y-2">
      {transactions.map((t) => (
        <div key={t.id} className="flex items-center gap-4 bg-card border border-border rounded-xl px-4 py-3">
          <div className={cn("flex-shrink-0", t.type === "income" ? "text-green-500" : "text-red-500")}>{t.type === "income" ? <ArrowUpCircle className="h-6 w-6" /> : <ArrowDownCircle className="h-6 w-6" />}</div>
          <div className="flex-1 min-w-0"><p className="font-medium text-sm truncate">{t.description}</p><p className="text-xs text-muted-foreground">{categoryLabels[t.category] || t.category} · {t.date ? format(new Date(t.date), "dd/MM/yyyy") : ""}</p></div>
          <p className={cn("font-semibold text-sm flex-shrink-0", t.type === "income" ? "text-green-600" : "text-red-600")}>{t.type === "income" ? "+" : "-"}€{parseFloat(t.amount).toFixed(2)}</p>
          <Button variant="ghost" size="icon" className="flex-shrink-0 text-muted-foreground hover:text-destructive" onClick={() => onDelete(t.id)}><Trash2 className="h-4 w-4" /></Button>
        </div>
      ))}
    </div>
  );
}
