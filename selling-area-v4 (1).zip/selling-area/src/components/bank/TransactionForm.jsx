import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
export default function TransactionForm({ onSubmit, onCancel, isLoading }) {
  const today = new Date().toISOString().split("T")[0];
  const [form, setForm] = useState({ description: "", amount: "", type: "income", category: "other", date: today, notes: "" });
  const handleSubmit = (e) => { e.preventDefault(); onSubmit({ ...form, amount: parseFloat(form.amount) }); };
  return (
    <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 space-y-4">
      <h3 className="font-semibold text-lg">Nuova Transazione</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5"><Label>Descrizione *</Label><Input placeholder="es. Vendita iPhone" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required /></div>
        <div className="space-y-1.5"><Label>Importo (€) *</Label><Input type="number" step="0.01" min="0" placeholder="0.00" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required /></div>
        <div className="space-y-1.5"><Label>Tipo *</Label><Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="income">Entrata</SelectItem><SelectItem value="expense">Uscita</SelectItem></SelectContent></Select></div>
        <div className="space-y-1.5"><Label>Categoria</Label><Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="purchase">Acquisto</SelectItem><SelectItem value="sale">Vendita</SelectItem><SelectItem value="shipping">Spedizione</SelectItem><SelectItem value="fee">Commissione</SelectItem><SelectItem value="tax">Tasse</SelectItem><SelectItem value="other">Altro</SelectItem></SelectContent></Select></div>
        <div className="space-y-1.5"><Label>Data *</Label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required /></div>
        <div className="space-y-1.5"><Label>Note</Label><Input placeholder="Note opzionali" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
      </div>
      <div className="flex justify-end gap-3 pt-2"><Button type="button" variant="outline" onClick={onCancel}>Annulla</Button><Button type="submit" disabled={isLoading}>{isLoading ? "Salvataggio..." : "Salva"}</Button></div>
    </form>
  );
}
