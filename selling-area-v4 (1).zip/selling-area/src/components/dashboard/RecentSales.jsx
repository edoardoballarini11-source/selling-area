import { format } from "date-fns";
import { TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";
export default function RecentSales({ items }) {
  const soldItems = items.filter((i) => i.status === "sold").sort((a, b) => new Date(b.sell_date) - new Date(a.sell_date)).slice(0, 5);
  if (soldItems.length === 0) return (<div className="bg-card border border-border rounded-2xl p-6"><h3 className="font-display text-lg font-semibold mb-4">Recent Sales</h3><p className="text-sm text-muted-foreground text-center py-8">No sales yet. Start selling to see your profits!</p></div>);
  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <h3 className="font-display text-lg font-semibold mb-4">Recent Sales</h3>
      <div className="space-y-4">
        {soldItems.map((item) => {
          const profit = item.sell_price - item.purchase_price;
          return (
            <div key={item.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">{item.name?.[0]?.toUpperCase()}</div>
                <div><p className="text-sm font-medium">{item.name}</p><p className="text-xs text-muted-foreground">{item.sell_date ? format(new Date(item.sell_date), "MMM d") : ""}</p></div>
              </div>
              <div className="flex items-center gap-1.5">
                {profit >= 0 ? <TrendingUp className="h-3.5 w-3.5 text-green-500" /> : <TrendingDown className="h-3.5 w-3.5 text-red-500" />}
                <span className={cn("text-sm font-semibold", profit >= 0 ? "text-green-600" : "text-red-500")}>{profit >= 0 ? "+" : ""}€{profit.toFixed(2)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
