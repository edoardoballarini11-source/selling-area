import { cn } from "@/lib/utils";
export default function StatCard({ title, value, icon: Icon, trend, trendLabel, variant = "default" }) {
  return (
    <div className={cn("rounded-2xl p-6 transition-all duration-300 hover:shadow-lg", variant === "primary" ? "bg-primary text-primary-foreground" : "bg-card border border-border")}>
      <div className="flex items-start justify-between">
        <div><p className={cn("text-sm font-medium", variant === "primary" ? "text-primary-foreground/70" : "text-muted-foreground")}>{title}</p><p className="text-3xl font-bold mt-2 tracking-tight">{value}</p></div>
        <div className={cn("h-11 w-11 rounded-xl flex items-center justify-center", variant === "primary" ? "bg-primary-foreground/15" : "bg-accent")}><Icon className={cn("h-5 w-5", variant === "primary" ? "text-primary-foreground" : "text-accent-foreground")} /></div>
      </div>
      {trend !== undefined && (<div className="flex items-center gap-1.5 mt-4"><span className={cn("text-sm font-semibold", trend >= 0 ? "text-green-500" : "text-red-500", variant === "primary" && (trend >= 0 ? "text-green-300" : "text-red-300"))}>{trend >= 0 ? "+" : ""}{trend}%</span>{trendLabel && <span className={cn("text-xs", variant === "primary" ? "text-primary-foreground/60" : "text-muted-foreground")}>{trendLabel}</span>}</div>)}
    </div>
  );
}
