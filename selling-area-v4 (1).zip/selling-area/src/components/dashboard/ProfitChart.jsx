import { useState, useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { format, eachDayOfInterval, eachWeekOfInterval, eachMonthOfInterval, startOfWeek, subDays, subMonths, subYears } from "date-fns";
import { it } from "date-fns/locale";
const VIEWS = [{ key: "daily", label: "Giornaliero" }, { key: "weekly", label: "Settimanale" }, { key: "monthly", label: "Mensile" }, { key: "yearly", label: "Annuale" }];
function buildData(soldItems, view) {
  const now = new Date(); let intervals = []; let formatKey; let formatLabel;
  if (view === "daily") { const start = subDays(now, 29); intervals = eachDayOfInterval({ start, end: now }); formatKey = (d) => format(d, "yyyy-MM-dd"); formatLabel = (d) => format(d, "d MMM", { locale: it }); }
  else if (view === "weekly") { const start = subDays(now, 83); intervals = eachWeekOfInterval({ start, end: now }, { weekStartsOn: 1 }); formatKey = (d) => format(startOfWeek(d, { weekStartsOn: 1 }), "yyyy-MM-dd"); formatLabel = (d) => format(d, "d MMM", { locale: it }); }
  else if (view === "monthly") { const start = subMonths(now, 11); intervals = eachMonthOfInterval({ start, end: now }); formatKey = (d) => format(d, "yyyy-MM"); formatLabel = (d) => format(d, "MMM yyyy", { locale: it }); }
  else { const startYear = subYears(now, 4).getFullYear(); for (let y = startYear; y <= now.getFullYear(); y++) intervals.push(new Date(y, 0, 1)); formatKey = (d) => format(d, "yyyy"); formatLabel = (d) => format(d, "yyyy"); }
  const map = {};
  intervals.forEach((d) => { map[formatKey(d)] = { label: formatLabel(d), profit: 0 }; });
  soldItems.forEach((item) => {
    const d = new Date(item.sell_date); let key;
    if (view === "daily") key = format(d, "yyyy-MM-dd");
    else if (view === "weekly") key = format(startOfWeek(d, { weekStartsOn: 1 }), "yyyy-MM-dd");
    else if (view === "monthly") key = format(d, "yyyy-MM");
    else key = format(d, "yyyy");
    if (map[key] !== undefined) map[key].profit += item.sell_price - item.purchase_price;
  });
  return Object.values(map);
}
export default function ProfitChart({ items }) {
  const [view, setView] = useState("monthly");
  const soldItems = items.filter((i) => i.status === "sold" && i.sell_date && i.sell_price != null);
  const data = useMemo(() => buildData(soldItems, view), [soldItems, view]);
  const hasData = data.some((d) => d.profit !== 0);
  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <h3 className="font-display text-lg font-semibold">Andamento Profitti</h3>
        <div className="flex gap-1 bg-muted rounded-xl p-1">
          {VIEWS.map(({ key, label }) => (<button key={key} onClick={() => setView(key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${view === key ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>{label}</button>))}
        </div>
      </div>
      {!hasData ? <p className="text-sm text-muted-foreground text-center py-12">Nessuna vendita nel periodo selezionato.</p> : (
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fontSize: 11 }} interval="preserveStartEnd" />
            <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11 }} tickFormatter={(v) => `€${v}`} />
            <Tooltip formatter={(value) => [`€${value.toFixed(2)}`, "Profitto"]} contentStyle={{ borderRadius: "12px", border: "1px solid hsl(var(--border))", background: "hsl(var(--card))", fontSize: "13px" }} />
            <Line type="monotone" dataKey="profit" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
