import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Package, PlusCircle, Settings, Landmark, Store, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
  { label: "Inventory", path: "/inventory", icon: Package },
  { label: "Add Item", path: "/add-item", icon: PlusCircle },
  { label: "Ordini in Attesa", path: "/pending-orders", icon: Clock },
  { label: "Conto Bancario", path: "/bank", icon: Landmark },
  { label: "Settings", path: "/settings", icon: Settings },
];

export default function Sidebar() {
  const location = useLocation();
  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card min-h-screen p-6">
      <div className="flex items-center gap-3 mb-10">
        <div className="h-10 w-10 rounded-xl bg-primary flex items-center justify-center">
          <span className="text-primary-foreground font-bold text-lg">S</span>
        </div>
        <div>
          <h1 className="font-display text-xl font-bold text-foreground">Selling Area</h1>
          <p className="text-xs text-muted-foreground">Buy low, sell high</p>
        </div>
      </div>
      <nav className="flex flex-col gap-1.5 flex-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link key={item.path} to={item.path}
              className={cn("flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                isActive ? "bg-primary text-primary-foreground shadow-md" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground")}>
              <item.icon className="h-4 w-4" />{item.label}
            </Link>
          );
        })}
      </nav>
      <Link to="/" className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-all duration-200 mt-4">
        <Store className="h-4 w-4" />Vai alla Vetrina
      </Link>
    </aside>
  );
}
