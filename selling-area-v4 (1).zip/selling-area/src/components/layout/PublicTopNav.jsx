import { Link, useLocation } from "react-router-dom";
import { Package, Landmark, BarChart2, TrendingUp, Settings } from "lucide-react";
const NAV_LINKS = [
  { label: "Shop", path: "/", icon: Package },
  { label: "Conto Bancario", path: "/public/bank", icon: Landmark },
  { label: "Profit Predictor", path: "/public/profit-predictor", icon: BarChart2 },
  { label: "Market Trends", path: "/public/market-trends", icon: TrendingUp },
  { label: "Settings", path: "/public/settings", icon: Settings },
];
export default function PublicTopNav() {
  const location = useLocation();
  return (
    <div className="sticky top-0 z-40 bg-card border-b border-border px-4 overflow-x-auto">
      <div className="flex max-w-6xl mx-auto">
        {NAV_LINKS.map(({ label, path, icon: Icon }) => {
          const isActive = location.pathname === path;
          return <Link key={path} to={path} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${isActive ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}><Icon className="h-4 w-4" />{label}</Link>;
        })}
      </div>
    </div>
  );
}
