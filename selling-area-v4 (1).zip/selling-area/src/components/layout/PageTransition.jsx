import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "react-router-dom";
const variants = { initial: { x: "100%", opacity: 0 }, animate: { x: 0, opacity: 1 }, exit: { x: "-30%", opacity: 0 } };
const transition = { type: "tween", ease: "easeInOut", duration: 0.25 };
export default function PageTransition({ children }) {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div key={location.pathname} variants={variants} initial="initial" animate="animate" exit="exit" transition={transition} style={{ willChange: "transform, opacity" }} className="min-h-full">{children}</motion.div>
    </AnimatePresence>
  );
}
