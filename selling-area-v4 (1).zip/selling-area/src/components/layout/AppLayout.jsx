import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import MobileNav from "./MobileNav";
import PageTransition from "./PageTransition";
export default function AppLayout() {
  return (
    <div className="flex bg-background" style={{ minHeight: "100dvh", paddingTop: "env(safe-area-inset-top)" }}>
      <Sidebar />
      <main className="flex-1 overflow-auto" style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 5rem)" }}>
        <PageTransition><Outlet /></PageTransition>
      </main>
      <MobileNav />
    </div>
  );
}
