import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Package, PlusCircle, Settings, Landmark, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
  { label: "Inventory", path: "/inventory", icon: Package },
  { label: "Ordini", path: "/pending-orders", icon: Clock },
  { label: "Add", path: "/add-item", icon: PlusCircle },
  { label: "Banca", path: "/bank", icon: Landmark },
  { label: "Settings", path: "/settings", icon: Settings },
];

export default function MobileNav() {
  const location = useLocation();
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border px-2" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link key={item.path} to={item.path}
              className={cn("flex flex-col items-center gap-1 px-3 py-2 rounded-xl text-xs font-medium transition-all",
                isActive ? "text-primary" : "text-muted-foreground")}>
              <item.icon className={cn("h-5 w-5", isActive && "stroke-[2.5]")} />{item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
