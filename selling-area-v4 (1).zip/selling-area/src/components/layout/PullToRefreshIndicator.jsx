import { Loader2, ArrowDown } from "lucide-react";
export default function PullToRefreshIndicator({ pullDistance, threshold, refreshing }) {
  const progress = Math.min(pullDistance / threshold, 1);
  const ready = pullDistance >= threshold;
  if (!refreshing && pullDistance === 0) return null;
  return (
    <div className="absolute top-0 left-0 right-0 flex items-center justify-center z-40 pointer-events-none transition-all" style={{ height: pullDistance, opacity: progress }}>
      <div className="flex items-center gap-2 bg-card border border-border rounded-full px-4 py-2 shadow-md text-sm font-medium text-muted-foreground">
        {refreshing ? <Loader2 className="h-4 w-4 animate-spin text-primary" /> : <ArrowDown className="h-4 w-4 text-primary transition-transform duration-200" style={{ transform: ready ? "rotate(180deg)" : "rotate(0deg)" }} />}
        {refreshing ? "Refreshing..." : ready ? "Release to refresh" : "Pull to refresh"}
      </div>
    </div>
  );
}
