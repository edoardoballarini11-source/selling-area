import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, CheckCircle2, XCircle, Copy, ExternalLink, Truck, Clock } from "lucide-react";
import { toast } from "sonner";
const CORRIERI = ["Poste Italiane", "DHL", "GLS", "BRT"];
function OrderCard({ item, onApprove, onCancel }) {
  const [showTracking, setShowTracking] = useState(false);
  const [trackingCode, setTrackingCode] = useState("");
  const [corriere, setCorriere] = useState("");
  const [approving, setApproving] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const copyAddress = () => { const addr = `${item.buyer_name} ${item.buyer_surname}\n${item.buyer_address}\nTel: ${item.buyer_phone}`; navigator.clipboard.writeText(addr); toast.success("Indirizzo copiato!"); };
  const handleConfirmShipping = async () => {
    if (!trackingCode || !corriere) { toast.error("Inserisci codice di tracciamento e corriere."); return; }
    setApproving(true); await onApprove(item, trackingCode, corriere); setApproving(false);
  };
  const handleCancel = async () => { setCancelling(true); await onCancel(item); setCancelling(false); };
  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
      <div className="flex gap-4 p-5 border-b border-border">
        <div className="w-20 h-20 rounded-xl bg-muted overflow-hidden flex-shrink-0">{item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Package className="h-8 w-8 text-muted-foreground/30" /></div>}</div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-base truncate">{item.name}</h3>
          <p className="text-primary font-bold text-lg">€{item.sell_price?.toFixed(2) || "–"}</p>
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full mt-1"><Clock className="h-3 w-3" />In attesa di verifica</span>
        </div>
      </div>
      <div className="p-5 space-y-3">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Dati Cliente</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
          <div><span className="text-muted-foreground">Nome:</span> <span className="font-medium">{item.buyer_name} {item.buyer_surname}</span></div>
          <div><span className="text-muted-foreground">Telefono:</span> <span className="font-medium">{item.buyer_phone || "–"}</span></div>
          <div className="sm:col-span-2"><span className="text-muted-foreground">Indirizzo:</span> <span className="font-medium">{item.buyer_address || "–"}</span></div>
        </div>
        <div className="flex flex-wrap gap-2 pt-1">
          <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={() => window.open("https://www.packlink.it", "_blank")}><ExternalLink className="h-3.5 w-3.5" />Genera Spedizione su Packlink</Button>
          <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={copyAddress}><Copy className="h-3.5 w-3.5" />Copia Indirizzo Cliente</Button>
        </div>
        {showTracking && (
          <div className="bg-muted/50 border border-border rounded-xl p-4 space-y-3 mt-2">
            <p className="text-sm font-semibold flex items-center gap-2"><Truck className="h-4 w-4 text-primary" />Inserisci dati di spedizione</p>
            <div className="space-y-2"><Label className="text-xs">Corriere *</Label><Select value={corriere} onValueChange={setCorriere}><SelectTrigger className="h-9"><SelectValue placeholder="Seleziona corriere..." /></SelectTrigger><SelectContent>{CORRIERI.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label className="text-xs">Codice di Tracciamento *</Label><Input value={trackingCode} onChange={(e) => setTrackingCode(e.target.value)} placeholder="es. 1234567890IT" className="h-9" /></div>
            <div className="flex gap-2 pt-1"><Button variant="outline" size="sm" className="flex-1" onClick={() => setShowTracking(false)}>Annulla</Button><Button size="sm" className="flex-1 bg-green-600 hover:bg-green-700 text-white" onClick={handleConfirmShipping} disabled={approving}>{approving ? "Salvataggio..." : "Conferma Spedizione"}</Button></div>
          </div>
        )}
        {!showTracking && (
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 border-red-200 text-red-600 hover:bg-red-50" onClick={handleCancel} disabled={cancelling}><XCircle className="h-4 w-4 mr-2" />{cancelling ? "Annullamento..." : "Annulla Ordine"}</Button>
            <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white" onClick={() => setShowTracking(true)}><CheckCircle2 className="h-4 w-4 mr-2" />Approva Vendita</Button>
          </div>
        )}
      </div>
    </div>
  );
}
export default function PendingOrders() {
  const queryClient = useQueryClient();
  const { data: items = [], isLoading } = useQuery({ queryKey: ["pending-orders"], queryFn: () => base44.entities.Item.filter({ status: "pending_payment" }) });
  const approveMutation = useMutation({
    mutationFn: async ({ item, trackingCode, corriere }) => { await base44.entities.Item.update(item.id, { status: "sold", sell_date: new Date().toISOString().split("T")[0], tracking_code: trackingCode, corriere }); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["pending-orders"] }); queryClient.invalidateQueries({ queryKey: ["items"] }); toast.success("Vendita approvata!"); },
  });
  const cancelMutation = useMutation({
    mutationFn: async (item) => { await base44.entities.Item.update(item.id, { status: "in_stock", buyer_name: "", buyer_surname: "", buyer_address: "", buyer_phone: "", tracking_code: "", corriere: "" }); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["pending-orders"] }); queryClient.invalidateQueries({ queryKey: ["items"] }); queryClient.invalidateQueries({ queryKey: ["shop-items"] }); toast.success("Ordine annullato."); },
  });
  return (
    <div className="p-6 md:p-10 space-y-6 max-w-4xl mx-auto">
      <div><h1 className="font-display text-3xl font-bold">Ordini in Attesa</h1><p className="text-muted-foreground mt-1">Verifica i pagamenti e gestisci le spedizioni</p></div>
      {isLoading ? <div className="space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-64 rounded-2xl" />)}</div>
      : items.length === 0 ? <div className="text-center py-20 text-muted-foreground"><CheckCircle2 className="h-12 w-12 mx-auto mb-4 opacity-30" /><p className="font-medium">Nessun ordine in attesa</p><p className="text-sm mt-1">Tutti i pagamenti sono stati verificati.</p></div>
      : <div className="grid gap-5">{items.map((item) => <OrderCard key={item.id} item={item} onApprove={(item, trackingCode, corriere) => approveMutation.mutateAsync({ item, trackingCode, corriere })} onCancel={(item) => cancelMutation.mutateAsync(item)} />)}</div>}
    </div>
  );
}
