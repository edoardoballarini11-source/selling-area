import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PlusCircle, TrendingUp, TrendingDown, Wallet } from "lucide-react";
import PublicTopNav from "@/components/layout/PublicTopNav";
import TransactionForm from "@/components/bank/TransactionForm";
import TransactionList from "@/components/bank/TransactionList";

export default function BankAccount() {
  const [showForm, setShowForm] = useState(false);
  const queryClient = useQueryClient();
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.BankTransaction.list("-date"),
  });
  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BankTransaction.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["transactions"] }); setShowForm(false); },
  });
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BankTransaction.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["transactions"] }),
  });
  const totalIncome = transactions.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const balance = totalIncome - totalExpense;
  const isPublic = window.location.pathname.startsWith("/public");
  return (
    <div>
      {isPublic && <PublicTopNav />}
      <div className="p-6 md:p-10 space-y-6 max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold">Conto Bancario</h1>
            <p className="text-muted-foreground mt-1">Gestisci le tue transazioni manualmente</p>
          </div>
          <Button onClick={() => setShowForm(true)}><PlusCircle className="h-4 w-4 mr-2" />Nuova Transazione</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className={`rounded-2xl p-5 border ${balance >= 0 ? "bg-primary text-primary-foreground" : "bg-destructive/10 border-destructive/20"}`}>
            <div className="flex items-center justify-between">
              <p className={`text-sm font-medium ${balance >= 0 ? "text-primary-foreground/70" : "text-muted-foreground"}`}>Saldo</p>
              <Wallet className="h-5 w-5 opacity-70" />
            </div>
            <p className="text-2xl font-bold mt-1">{balance >= 0 ? "+" : ""}€{balance.toFixed(2)}</p>
          </div>
          <div className="rounded-2xl p-5 border border-border bg-card">
            <div className="flex items-center justify-between"><p className="text-sm font-medium text-muted-foreground">Entrate</p><TrendingUp className="h-5 w-5 text-green-500" /></div>
            <p className="text-2xl font-bold mt-1 text-green-600">+€{totalIncome.toFixed(2)}</p>
          </div>
          <div className="rounded-2xl p-5 border border-border bg-card">
            <div className="flex items-center justify-between"><p className="text-sm font-medium text-muted-foreground">Uscite</p><TrendingDown className="h-5 w-5 text-red-500" /></div>
            <p className="text-2xl font-bold mt-1 text-red-600">-€{totalExpense.toFixed(2)}</p>
          </div>
        </div>
        {showForm && <TransactionForm onSubmit={(data) => createMutation.mutate(data)} onCancel={() => setShowForm(false)} isLoading={createMutation.isPending} />}
        {isLoading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
        ) : (
          <TransactionList transactions={transactions} onDelete={(id) => deleteMutation.mutate(id)} />
        )}
      </div>
    </div>
  );
}
