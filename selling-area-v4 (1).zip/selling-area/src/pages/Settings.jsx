import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ArrowLeft, Trash2, LogOut, Moon, Sun, Monitor } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function Settings() {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [activeTheme, setActiveTheme] = useState("dark");
  const navigate = useNavigate();

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const items = await base44.entities.Item.list();
      await Promise.all(items.map((i) => base44.entities.Item.delete(i.id)));
      toast.success("Account data deleted.");
      base44.auth.logout();
    } catch { toast.error("Something went wrong. Please try again."); }
    finally { setIsDeleting(false); setShowDeleteDialog(false); }
  };

  const handleLogout = () => base44.auth.logout();

  const setTheme = (theme) => {
    setActiveTheme(theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else if (theme === "light") {
      document.documentElement.classList.remove("dark");
    } else {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      prefersDark ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark");
    }
  };

  const isPublic = window.location.pathname.startsWith("/public");

  return (
    <div className="p-6 md:p-10 max-w-xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Link to="/"><Button variant="ghost" size="icon" className="rounded-xl"><ArrowLeft className="h-5 w-5" /></Button></Link>
        <div><h1 className="font-display text-3xl font-bold">Settings</h1><p className="text-muted-foreground mt-1">App preferences</p></div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
        <h2 className="font-semibold text-lg">Appearance</h2>
        <div className="flex gap-3">
          {[{ label: "Light", icon: Sun, value: "light" }, { label: "System", icon: Monitor, value: "system" }, { label: "Dark", icon: Moon, value: "dark" }].map(({ label, icon: Icon, value }) => (
            <button key={value} onClick={() => setTheme(value)}
              className={`flex-1 flex flex-col items-center gap-2 py-4 rounded-xl border transition-colors text-sm font-medium ${activeTheme === value ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 hover:bg-accent text-muted-foreground hover:text-foreground"}`}>
              <Icon className="h-5 w-5" />{label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 space-y-3">
        <h2 className="font-semibold text-lg">Account</h2>
        <Button variant="outline" className="w-full justify-start gap-3" onClick={handleLogout}><LogOut className="h-4 w-4" />Log Out</Button>
        <Button variant="outline" className="w-full justify-start gap-3 text-destructive border-destructive/30 hover:bg-destructive/10 hover:text-destructive" onClick={() => setShowDeleteDialog(true)}><Trash2 className="h-4 w-4" />Delete Account</Button>
      </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete Account?</AlertDialogTitle><AlertDialogDescription>This will permanently delete all your items and data. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowDeleteDialog(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAccount} disabled={isDeleting} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{isDeleting ? "Deleting..." : "Yes, delete everything"}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
