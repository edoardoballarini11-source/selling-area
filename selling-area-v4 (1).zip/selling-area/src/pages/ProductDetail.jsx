import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Package, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import CheckoutDialog from "@/components/shop/CheckoutDialog";
import { Skeleton } from "@/components/ui/skeleton";
const CATEGORY_LABELS = { electronics:"Elettronica",clothing:"Abbigliamento",furniture:"Arredamento",collectibles:"Collezionismo",vehicles:"Veicoli",jewelry:"Gioielleria",tools:"Utensili",sports:"Sport",books:"Libri",other:"Altro" };
const CATEGORY_STYLES = { electronics:"bg-blue-100 text-blue-700",clothing:"bg-pink-100 text-pink-700",furniture:"bg-amber-100 text-amber-700",collectibles:"bg-purple-100 text-purple-700",vehicles:"bg-slate-100 text-slate-700",jewelry:"bg-yellow-100 text-yellow-700",tools:"bg-orange-100 text-orange-700",sports:"bg-green-100 text-green-700",books:"bg-cyan-100 text-cyan-700",other:"bg-muted text-muted-foreground" };
export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const { data: item, isLoading } = useQuery({ queryKey: ["item", id], queryFn: async () => { const items = await base44.entities.Item.filter({ id }); return items[0] ?? null; } });
  if (isLoading) return <div className="min-h-screen bg-background p-6 max-w-2xl mx-auto space-y-6"><Skeleton className="h-8 w-32 rounded-xl" /><Skeleton className="h-72 rounded-2xl" /><Skeleton className="h-48 rounded-2xl" /></div>;
  if (!item || item.status === "sold") return <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-muted-foreground"><Package className="h-16 w-16 opacity-20" /><p className="text-lg font-medium">Prodotto non disponibile</p><Button variant="outline" onClick={() => navigate("/")}>Torna alla vetrina</Button></div>;
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <button onClick={() => navigate("/")} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"><ArrowLeft className="h-4 w-4" />Torna alla vetrina</button>
        <div className="rounded-2xl overflow-hidden border border-border bg-muted h-72">
          {item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Package className="h-16 w-16 text-muted-foreground/30" /></div>}
        </div>
        <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div><span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${CATEGORY_STYLES[item.category] || CATEGORY_STYLES.other}`}>{CATEGORY_LABELS[item.category] || item.category}</span><h1 className="font-display text-2xl font-bold mt-3">{item.name}</h1></div>
            {item.sell_price && <p className="text-primary font-bold text-2xl whitespace-nowrap">€{item.sell_price.toFixed(2)}</p>}
          </div>
          {item.description && <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>}
          {item.notes && <div className="bg-muted/50 rounded-xl p-4"><p className="text-xs font-semibold text-muted-foreground mb-1">Note del venditore</p><p className="text-sm">{item.notes}</p></div>}
          <Button className="w-full h-12 text-base font-semibold mt-2" onClick={() => setCheckoutOpen(true)}><ShoppingCart className="h-5 w-5 mr-2" />Acquista Ora</Button>
        </div>
      </div>
      <CheckoutDialog open={checkoutOpen} onOpenChange={setCheckoutOpen} item={item} />
    </div>
  );
}
