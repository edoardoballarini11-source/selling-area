import { TrendingUp } from "lucide-react";
import PublicTopNav from "@/components/layout/PublicTopNav";
const TRENDING_PRODUCTS = [
  { name: "PS5 Pro", category: "electronics", tags: ["Richiesta Alta", "Margine Ottimale"] },
  { name: "Nike Air Jordan 1 Retro High OG", category: "sneakers", tags: ["Richiesta Alta"] },
  { name: "iPhone 16 Pro Max", category: "electronics", tags: ["Richiesta Alta", "Margine Ottimale"] },
  { name: "Adidas Yeezy 350 V2", category: "sneakers", tags: ["Margine Ottimale"] },
  { name: "Lego Technic Bugatti Chiron", category: "collectibles", tags: ["Richiesta Alta"] },
  { name: "Supreme Box Logo Hoodie", category: "clothing", tags: ["Richiesta Alta", "Margine Ottimale"] },
  { name: "MacBook Air M3", category: "electronics", tags: ["Margine Ottimale"] },
  { name: "Pokémon Card Charizard ex", category: "collectibles", tags: ["Richiesta Alta", "Margine Ottimale"] },
  { name: "Rolex Submariner", category: "jewelry", tags: ["Margine Ottimale"] },
  { name: "Nintendo Switch 2", category: "electronics", tags: ["Richiesta Alta"] },
  { name: "New Balance 990v6", category: "sneakers", tags: ["Richiesta Alta"] },
  { name: "Stanley Quencher Tumbler", category: "other", tags: ["Richiesta Alta", "Margine Ottimale"] },
];
const CATEGORY_STYLES = {
  electronics: { label: "Elettronica", className: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" },
  sneakers: { label: "Sneakers", className: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300" },
  collectibles: { label: "Collezionismo", className: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300" },
  clothing: { label: "Abbigliamento", className: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300" },
  jewelry: { label: "Gioielleria", className: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300" },
  other: { label: "Altro", className: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300" },
};
const TAG_STYLES = {
  "Richiesta Alta": "bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300",
  "Margine Ottimale": "bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-900/30 dark:text-amber-300",
};
export default function MarketTrends() {
  const isPublic = window.location.pathname.startsWith("/public");
  return (
    <div>{isPublic && <PublicTopNav />}
      <div className="p-6 md:p-10 max-w-4xl mx-auto space-y-8">
        <div><div className="flex items-center gap-3 mb-1"><TrendingUp className="h-7 w-7 text-primary" /><h1 className="font-display text-3xl font-bold">Market Trends</h1></div><p className="text-muted-foreground text-sm">Prodotti di tendenza nel reselling — aggiornati manualmente dalla redazione.</p></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {TRENDING_PRODUCTS.map((product) => {
            const cat = CATEGORY_STYLES[product.category] ?? CATEGORY_STYLES.other;
            return (
              <div key={product.name} className="bg-card border border-border rounded-2xl p-4 flex flex-col gap-3 hover:shadow-md transition-shadow">
                <span className={`self-start text-xs font-semibold px-2.5 py-1 rounded-full ${cat.className}`}>{cat.label}</span>
                <p className="font-semibold text-sm leading-snug">{product.name}</p>
                <div className="flex flex-wrap gap-2 mt-auto">
                  {product.tags.map((tag) => <span key={tag} className={`flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full ${TAG_STYLES[tag]}`}><TrendingUp className="h-3 w-3" />{tag}</span>)}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
