import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { DollarSign, Package, TrendingUp, ShoppingCart } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import StatCard from "@/components/dashboard/StatCard";
import RecentSales from "@/components/dashboard/RecentSales";
import ProfitChart from "@/components/dashboard/ProfitChart";
import usePullToRefresh from "@/hooks/usePullToRefresh";
import PullToRefreshIndicator from "@/components/layout/PullToRefreshIndicator";

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { data: items = [], isLoading } = useQuery({
    queryKey: ["items"],
    queryFn: () => base44.entities.Item.list("-created_date")
  });
  const handleRefresh = async () => { await queryClient.invalidateQueries({ queryKey: ["items"] }); };
  const { containerRef, pulling, pullDistance, refreshing, threshold } = usePullToRefresh(handleRefresh);
  const inStockItems = items.filter((i) => i.status === "in_stock");
  const soldItems = items.filter((i) => i.status === "sold");
  const totalRevenue = soldItems.reduce((s, i) => s + (i.sell_price || 0), 0);
  const totalCost = soldItems.reduce((s, i) => s + (i.purchase_price || 0), 0);
  const totalProfit = totalRevenue - totalCost;
  return (
    <div ref={containerRef} className="relative overflow-auto h-full">
      <PullToRefreshIndicator pullDistance={pullDistance} threshold={threshold} refreshing={refreshing} />
      <div className="p-6 md:p-10 space-y-8 max-w-7xl mx-auto transition-transform duration-150"
        style={{ transform: pulling || refreshing ? `translateY(${Math.min(pullDistance, threshold)}px)` : "none" }}>
        <div>
          <h1 className="font-display text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Track your buy and your sell profits</p>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard title="Total Profit" value={`€${totalProfit.toFixed(2)}`} icon={TrendingUp} variant="primary" />
              <StatCard title="Revenue" value={`€${totalRevenue.toFixed(2)}`} icon={DollarSign} />
              <StatCard title="In Stock" value={inStockItems.length} icon={Package} />
              <StatCard title="Items Sold" value={soldItems.length} icon={ShoppingCart} />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              <div className="lg:col-span-3"><ProfitChart items={items} /></div>
              <div className="lg:col-span-2"><RecentSales items={items} /></div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
