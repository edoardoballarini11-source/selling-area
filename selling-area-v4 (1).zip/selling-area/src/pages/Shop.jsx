import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate, Link } from "react-router-dom";
import { Package, Search, Gem } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import PublicTopNav from "@/components/layout/PublicTopNav";

const CATEGORY_LABELS = { electronics:"Elettronica",clothing:"Abbigliamento",furniture:"Arredamento",collectibles:"Collezionismo",vehicles:"Veicoli",jewelry:"Gioielleria",tools:"Utensili",sports:"Sport",books:"Libri",other:"Altro" };
const CATEGORY_STYLES = { electronics:"bg-blue-100 text-blue-700",clothing:"bg-pink-100 text-pink-700",furniture:"bg-amber-100 text-amber-700",collectibles:"bg-purple-100 text-purple-700",vehicles:"bg-slate-100 text-slate-700",jewelry:"bg-yellow-100 text-yellow-700",tools:"bg-orange-100 text-orange-700",sports:"bg-green-100 text-green-700",books:"bg-cyan-100 text-cyan-700",other:"bg-muted text-muted-foreground" };

export default function Shop() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["shop-items"],
    queryFn: async () => {
      const all = await base44.entities.Item.list("-created_date");
      return all.filter((i) => i.status === "in_stock");
    },
  });

  const categories = ["all", ...Object.keys(CATEGORY_LABELS)];
  const filtered = items.filter((item) => {
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = selectedCategory === "all" || item.category === selectedCategory;
    return matchSearch && matchCat;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border px-6 py-6 text-center relative">
        <div className="absolute right-4 top-4 flex items-center gap-2">
          <Link
            to="/diventa-venditore"
            className="flex items-center gap-2 text-xs font-semibold bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Gem className="h-3.5 w-3.5" />
            Diventa Venditore
          </Link>
          <a
            href="/dashboard"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors border border-border rounded-lg px-3 py-1.5"
          >
            Admin →
          </a>
        </div>
        <h1 className="font-display text-4xl font-bold">Selling Area</h1>
        <p className="text-muted-foreground mt-2">Trova il tuo prossimo affare</p>
      </div>

      <PublicTopNav />

      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        {/* Search */}
        <div className="relative max-w-lg mx-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Cerca prodotti..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        {/* Category filters */}
        <div className="flex gap-2 flex-wrap justify-center">
          {categories.map((cat) => (
            <button key={cat} onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all border ${selectedCategory === cat ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground hover:border-primary/50"}`}>
              {cat === "all" ? "Tutti" : CATEGORY_LABELS[cat]}
            </button>
          ))}
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-72 rounded-2xl" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-4 opacity-30" />
            <p>Nessun prodotto disponibile</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((item) => (
              <div key={item.id} onClick={() => navigate(`/product/${item.id}`)}
                className="group bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer">
                <div className="relative h-44 bg-muted overflow-hidden">
                  {item.image_url
                    ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    : <div className="w-full h-full flex items-center justify-center"><Package className="h-12 w-12 text-muted-foreground/30" /></div>}
                </div>
                <div className="p-4 space-y-3">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${CATEGORY_STYLES[item.category] || CATEGORY_STYLES.other}`}>
                    {CATEGORY_LABELS[item.category] || item.category}
                  </span>
                  <h3 className="font-semibold text-sm leading-snug mt-2">{item.name}</h3>
                  {item.sell_price && <p className="text-primary font-bold text-lg">€{item.sell_price.toFixed(2)}</p>}
                  <button className="w-full mt-2 bg-primary text-primary-foreground text-sm font-semibold py-2 rounded-xl hover:bg-primary/90 transition-colors">
                    Vedi Dettagli →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
