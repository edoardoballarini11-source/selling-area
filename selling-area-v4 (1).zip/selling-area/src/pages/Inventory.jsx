import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, PlusCircle, Package } from "lucide-react";
import { Link } from "react-router-dom";
import ItemCard from "@/components/inventory/ItemCard";
import SellDialog from "@/components/inventory/SellDialog";
import usePullToRefresh from "@/hooks/usePullToRefresh";
import PullToRefreshIndicator from "@/components/layout/PullToRefreshIndicator";

export default function Inventory() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sellItem, setSellItem] = useState(null);
  const queryClient = useQueryClient();
  const { data: items = [], isLoading } = useQuery({ queryKey: ["items"], queryFn: () => base44.entities.Item.list("-created_date") });
  const handleRefresh = async () => { await queryClient.invalidateQueries({ queryKey: ["items"] }); };
  const { containerRef, pulling, pullDistance, refreshing, threshold } = usePullToRefresh(handleRefresh);
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Item.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["items"] }); setSellItem(null); },
  });
  const filteredItems = items.filter((item) => {
    const matchSearch = item.name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || item.status === statusFilter;
    const matchCategory = categoryFilter === "all" || item.category === categoryFilter;
    return matchSearch && matchStatus && matchCategory;
  });
  return (
    <div ref={containerRef} className="relative overflow-auto h-full">
      <PullToRefreshIndicator pullDistance={pullDistance} threshold={threshold} refreshing={refreshing} />
      <div className="p-6 md:p-10 space-y-6 max-w-7xl mx-auto transition-transform duration-150"
        style={{ transform: pulling || refreshing ? `translateY(${Math.min(pullDistance, threshold)}px)` : "none" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div><h1 className="font-display text-3xl font-bold">Inventory</h1><p className="text-muted-foreground mt-1">{items.length} items total</p></div>
          <Link to="/add-item"><Button><PlusCircle className="h-4 w-4 mr-2" />Add Item</Button></Link>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search items..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="in_stock">In Stock</SelectItem>
              <SelectItem value="sold">Sold</SelectItem>
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="electronics">Electronics</SelectItem>
              <SelectItem value="clothing">Clothing</SelectItem>
              <SelectItem value="furniture">Furniture</SelectItem>
              <SelectItem value="collectibles">Collectibles</SelectItem>
              <SelectItem value="vehicles">Vehicles</SelectItem>
              <SelectItem value="jewelry">Jewelry</SelectItem>
              <SelectItem value="tools">Tools</SelectItem>
              <SelectItem value="sports">Sports</SelectItem>
              <SelectItem value="books">Books</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-80 rounded-2xl" />)}</div>
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Package className="h-16 w-16 text-muted-foreground/30 mb-4" />
            <h3 className="text-lg font-semibold">No items found</h3>
            <p className="text-muted-foreground text-sm mt-1">Add your first item to get started</p>
            <Link to="/add-item" className="mt-4"><Button variant="outline"><PlusCircle className="h-4 w-4 mr-2" />Add Item</Button></Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredItems.map((item) => <ItemCard key={item.id} item={item} onSell={() => setSellItem(item)} />)}
          </div>
        )}
        <SellDialog item={sellItem} open={!!sellItem} onOpenChange={(open) => !open && setSellItem(null)}
          onConfirm={(data) => updateMutation.mutate({ id: sellItem.id, data })} isLoading={updateMutation.isPending} />
      </div>
    </div>
  );
}
