import { useState, useRef } from "react";
import { TrendingUp, TrendingDown, Upload, Loader2, Sparkles, Tag, Package, Star } from "lucide-react";
import PublicTopNav from "@/components/layout/PublicTopNav";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const categories = [
  { value: "electronics", label: "Elettronica" },
  { value: "clothing", label: "Abbigliamento" },
  { value: "furniture", label: "Mobili" },
  { value: "collectibles", label: "Oggetti da collezione" },
  { value: "vehicles", label: "Veicoli" },
  { value: "jewelry", label: "Gioielli" },
  { value: "tools", label: "Strumenti" },
  { value: "sports", label: "Sport" },
  { value: "books", label: "Libri" },
  { value: "sneakers", label: "Sneakers" },
  { value: "other", label: "Altro" },
];

const conditions = [
  { value: "new", label: "Nuovo" },
  { value: "like_new", label: "Come nuovo" },
  { value: "good", label: "Buono" },
  { value: "fair", label: "Discreto" },
  { value: "poor", label: "Usurato" },
];

export default function ProfitPredictor() {
  const [productName, setProductName] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState("");
  const [description, setDescription] = useState("");
  const [buyPrice, setBuyPrice] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const fileRef = useRef();

  const isPublic = window.location.pathname.startsWith("/public");

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = ev.target.result.split(",")[1];
      setImageBase64(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!productName && !imageFile) return;
    setLoading(true);
    setResult(null);
    setError(null);

    try {
      const categoryLabel = categories.find(c => c.value === category)?.label || category;
      const conditionLabel = conditions.find(c => c.value === condition)?.label || condition;

      const textPrompt = `Sei un esperto di reselling e mercati secondari italiani (eBay, Vinted, Subito, Facebook Marketplace).

Analizza questo prodotto e fornisci una stima del prezzo di vendita REALISTICA per il mercato italiano.

Prodotto: ${productName || "non specificato"}
Categoria: ${categoryLabel || "non specificata"}
Condizione: ${conditionLabel || "non specificata"}
Descrizione: ${description || "non fornita"}
Prezzo di acquisto: ${buyPrice ? `€${buyPrice}` : "non specificato"}
${imageFile ? "Immagine: allegata (analizzala per identificare il prodotto)" : ""}

Rispondi SOLO con un JSON valido, senza testo aggiuntivo, in questo formato:
{
  "productIdentified": "nome prodotto identificato",
  "priceMin": numero,
  "priceMax": numero,
  "priceBest": numero,
  "confidence": "alta|media|bassa",
  "reasoning": "spiegazione breve in italiano (max 2 frasi)",
  "tips": ["consiglio 1", "consiglio 2"],
  "profitEstimate": numero o null
}

Il profitEstimate è la differenza tra priceBest e il prezzo di acquisto (se fornito), altrimenti null.
Sii REALISTICO: basa i prezzi su prodotti reali venduti su eBay.it e Subito.it. Non gonfiare i prezzi.`;

      const messages = [];
      if (imageBase64) {
        messages.push({
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: imageFile.type, data: imageBase64 } },
            { type: "text", text: textPrompt }
          ]
        });
      } else {
        messages.push({ role: "user", content: textPrompt });
      }

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages,
        }),
      });

      const data = await response.json();
      const text = data.content?.[0]?.text || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
    } catch (err) {
      setError("Errore nell'analisi. Riprova.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const canAnalyze = (productName || imageFile) && !loading;

  return (
    <div>
      {isPublic && <PublicTopNav />}
      <div className="p-6 md:p-10 space-y-8 max-w-2xl mx-auto">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Sparkles className="h-7 w-7 text-primary" />
            <h1 className="font-display text-3xl font-bold">AI Price Estimator</h1>
          </div>
          <p className="text-muted-foreground mt-1">Carica una foto del prodotto e ottieni una stima del prezzo di vendita realistica</p>
        </div>

        {/* Image Upload */}
        <div>
          <Label>Foto del Prodotto</Label>
          <label className="mt-2 flex flex-col items-center justify-center h-48 rounded-2xl border-2 border-dashed border-border bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors overflow-hidden">
            {imagePreview ? (
              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Upload className="h-10 w-10 opacity-40" />
                <span className="text-sm font-medium">Carica una foto per una stima più accurata</span>
                <span className="text-xs opacity-60">JPG, PNG, WEBP</span>
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
          </label>
          {imagePreview && (
            <button onClick={() => { setImageFile(null); setImagePreview(null); setImageBase64(null); }} className="mt-2 text-xs text-muted-foreground hover:text-destructive transition-colors">
              Rimuovi immagine
            </button>
          )}
        </div>

        {/* Form Fields */}
        <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
          <h2 className="font-semibold text-base flex items-center gap-2">
            <Package className="h-4 w-4 text-primary" />
            Dettagli Prodotto
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Nome Prodotto</Label>
              <Input placeholder="es. iPhone 13, Tavolo IKEA, Air Jordan 1..." value={productName} onChange={(e) => setProductName(e.target.value)} />
            </div>

            <div className="space-y-1.5">
              <Label>Categoria</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><div className="flex items-center gap-2"><Tag className="h-4 w-4 text-muted-foreground" /><SelectValue placeholder="Seleziona..." /></div></SelectTrigger>
                <SelectContent>{categories.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Condizione</Label>
              <Select value={condition} onValueChange={setCondition}>
                <SelectTrigger><div className="flex items-center gap-2"><Star className="h-4 w-4 text-muted-foreground" /><SelectValue placeholder="Seleziona..." /></div></SelectTrigger>
                <SelectContent>{conditions.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <Label>Descrizione (opzionale)</Label>
              <Input placeholder="Dettagli aggiuntivi, difetti, accessori inclusi..." value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <Label>Prezzo di Acquisto (€) — opzionale</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">€</span>
                <Input type="number" min="0" step="0.01" placeholder="0.00" className="pl-7" value={buyPrice} onChange={(e) => setBuyPrice(e.target.value)} />
              </div>
            </div>
          </div>

          <Button className="w-full h-11" onClick={handleAnalyze} disabled={!canAnalyze}>
            {loading ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Analisi in corso...</>
            ) : (
              <><Sparkles className="h-4 w-4 mr-2" />Stima il Prezzo con AI</>
            )}
          </Button>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">{error}</div>
        )}

        {/* Result */}
        {result && (
          <div className="space-y-4 animate-in fade-in duration-500">
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              {/* Header */}
              <div className="bg-primary px-6 py-5">
                <p className="text-primary-foreground/70 text-sm font-medium mb-1">
                  {result.productIdentified}
                </p>
                <div className="flex items-end gap-3">
                  <span className="text-4xl font-bold text-primary-foreground">€{result.priceBest}</span>
                  <span className="text-primary-foreground/60 text-sm mb-1">prezzo consigliato</span>
                </div>
                <div className="mt-2 text-primary-foreground/70 text-sm">
                  Range: €{result.priceMin} – €{result.priceMax}
                </div>
              </div>

              {/* Body */}
              <div className="p-6 space-y-4">
                {/* Confidence */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Affidabilità stima:</span>
                  <span className={cn("text-xs font-bold px-2 py-0.5 rounded-full",
                    result.confidence === "alta" ? "bg-green-100 text-green-700" :
                    result.confidence === "media" ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  )}>{result.confidence?.charAt(0).toUpperCase() + result.confidence?.slice(1)}</span>
                </div>

                {/* Reasoning */}
                <div className="bg-muted/50 rounded-xl p-4">
                  <p className="text-sm text-muted-foreground leading-relaxed">{result.reasoning}</p>
                </div>

                {/* Profit */}
                {result.profitEstimate !== null && result.profitEstimate !== undefined && (
                  <div className={cn("flex items-center gap-3 rounded-xl px-4 py-3 border",
                    result.profitEstimate >= 0 ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                  )}>
                    {result.profitEstimate >= 0
                      ? <TrendingUp className="h-5 w-5 text-green-600" />
                      : <TrendingDown className="h-5 w-5 text-red-600" />}
                    <div>
                      <p className={cn("font-bold text-lg", result.profitEstimate >= 0 ? "text-green-700" : "text-red-700")}>
                        {result.profitEstimate >= 0 ? "+" : ""}€{result.profitEstimate.toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground">Profitto stimato</p>
                    </div>
                  </div>
                )}

                {/* Tips */}
                {result.tips?.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Consigli per vendere meglio</p>
                    {result.tips.map((tip, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-primary mt-0.5">•</span>
                        <span className="text-muted-foreground">{tip}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <button onClick={() => setResult(null)} className="text-xs text-muted-foreground hover:text-foreground transition-colors w-full text-center">
              Nuova analisi
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
