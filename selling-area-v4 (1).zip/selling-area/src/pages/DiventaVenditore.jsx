import { Link } from "react-router-dom";
import { CheckCircle2, Zap, Gem, Star, ArrowLeft } from "lucide-react";
import PublicTopNav from "@/components/layout/PublicTopNav";

const features = [
  "Sblocca la tua Dashboard personale con statistiche in tempo reale",
  "Inserisci i tuoi prodotti nel marketplace",
  "Gestisci i tuoi profitti con grafici giornalieri, settimanali, mensili e annuali",
  "Accedi ai moduli di spedizione veloci con Packlink",
];

export default function DiventaVenditore() {
  const handleMonthly = () => {
    alert("Per abilitare il piano mensile, contatta l'amministratore.");
  };
  const handleYearly = () => {
    alert("Per abilitare il piano annuale, contatta l'amministratore.");
  };

  return (
    <div className="min-h-screen bg-background">
      <PublicTopNav />
      <div className="max-w-4xl mx-auto px-4 py-16 space-y-10">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="font-display text-4xl md:text-5xl font-bold">Sblocca il tuo Business</h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Ottieni la tua dashboard personale, gestisci il magazzino e le spedizioni — tutto separato dagli altri venditori.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">

          {/* Monthly */}
          <div className="bg-card border border-border rounded-2xl p-8 space-y-6">
            <div className="flex items-center gap-3">
              <Zap className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-bold">Piano Pro Mensile</h2>
            </div>
            <div>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-bold text-primary">€9,99</span>
                <span className="text-muted-foreground mb-1">/mese</span>
              </div>
              <p className="text-muted-foreground text-sm mt-1">Flessibile, cancella quando vuoi</p>
            </div>
            <ul className="space-y-3">
              {features.map((f, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{f}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={handleMonthly}
              className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-colors">
              Richiedi Upgrade Mensile →
            </button>
          </div>

          {/* Yearly — highlighted */}
          <div className="relative bg-card border-2 border-primary rounded-2xl p-8 space-y-6">
            {/* Badge */}
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1.5 whitespace-nowrap">
              <Star className="h-3.5 w-3.5" />
              RISPARMIA IL 50%
            </div>

            <div className="flex items-center gap-3">
              <Gem className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-bold">Piano Pro Annuale</h2>
            </div>
            <div>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-bold text-primary">€59,99</span>
                <span className="text-muted-foreground mb-1">/anno</span>
              </div>
              <p className="text-sm mt-1">
                Solo <span className="text-primary font-semibold">€5,00/mese</span>
                <span className="text-muted-foreground"> — risparmia €60 l'anno</span>
              </p>
            </div>
            <ul className="space-y-3">
              {features.map((f, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{f}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={handleYearly}
              className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-colors">
              Richiedi Upgrade Annuale →
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          Hai già un account venditore?{" "}
          <Link to="/dashboard" className="text-primary hover:underline">Accedi alla dashboard →</Link>
        </p>
      </div>
    </div>
  );
}
