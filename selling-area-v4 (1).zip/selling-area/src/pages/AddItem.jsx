import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Upload, DollarSign, Loader2, Layers, TrendingUp } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function AddItem() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ name: "", description: "", category: "", purchase_price: "", selling_price: "", purchase_date: new Date().toISOString().split("T")[0], notes: "" });
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [isLot, setIsLot] = useState(false);
  const [lotTotalCost, setLotTotalCost] = useState("");
  const [lotQuantity, setLotQuantity] = useState("");

  const lotUnitCost = lotTotalCost && lotQuantity && parseFloat(lotQuantity) > 0 ? (parseFloat(lotTotalCost) / parseFloat(lotQuantity)).toFixed(2) : null;

  const purchasePriceNum = isLot && lotUnitCost ? parseFloat(lotUnitCost) : parseFloat(form.purchase_price);
  const sellingPriceNum = parseFloat(form.selling_price);
  const estimatedProfit = !isNaN(purchasePriceNum) && !isNaN(sellingPriceNum) && purchasePriceNum > 0 ? (sellingPriceNum - purchasePriceNum).toFixed(2) : null;
  const profitMargin = estimatedProfit !== null ? (((sellingPriceNum - purchasePriceNum) / purchasePriceNum) * 100).toFixed(1) : null;

  const createMutation = useMutation({
    mutationFn: async (data) => {
      let image_url = "";
      if (imageFile) { const result = await base44.integrations.Core.UploadFile({ file: imageFile }); image_url = result.file_url; }
      return base44.entities.Item.create({ ...data, image_url, status: "in_stock" });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["items"] }); toast.success("Item added successfully!"); navigate("/inventory"); },
  });

  const handleImageChange = (e) => { const file = e.target.files[0]; if (file) { setImageFile(file); setImagePreview(URL.createObjectURL(file)); } };
  const handleSubmit = (e) => {
    e.preventDefault();
    const price = isLot && lotUnitCost ? parseFloat(lotUnitCost) : parseFloat(form.purchase_price);
    createMutation.mutate({ ...form, purchase_price: price, selling_price: sellingPriceNum || null, ...(isLot && lotUnitCost ? { lot_total_cost: parseFloat(lotTotalCost), lot_quantity: parseFloat(lotQuantity), lot_reference: `Lotto ${lotQuantity}pz / €${lotTotalCost}` } : {}) });
  };
  const updateField = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Link to="/inventory"><Button variant="ghost" size="icon" className="rounded-xl"><ArrowLeft className="h-5 w-5" /></Button></Link>
        <div><h1 className="font-display text-3xl font-bold">Add Item</h1><p className="text-muted-foreground mt-1">Record a new purchase</p></div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center"><Layers className="h-5 w-5 text-primary" /></div>
              <div><p className="font-medium text-sm">Gestione Lotti (Bulk)</p><p className="text-xs text-muted-foreground">Fa parte di un lotto?</p></div>
            </div>
            <Switch checked={isLot} onCheckedChange={setIsLot} />
          </div>
          {isLot && (
            <div className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Costo Totale del Lotto (€)</Label><Input type="number" min="0" step="0.01" placeholder="0.00" value={lotTotalCost} onChange={(e) => setLotTotalCost(e.target.value)} /></div>
                <div className="space-y-1.5"><Label>Numero di Oggetti nel Lotto</Label><Input type="number" min="1" step="1" placeholder="es. 10" value={lotQuantity} onChange={(e) => setLotQuantity(e.target.value)} /></div>
              </div>
              {lotUnitCost && (
                <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-xl px-4 py-3">
                  <DollarSign className="h-4 w-4 text-primary" />
                  <p className="text-sm">Costo per pezzo: <span className="font-bold text-primary">€{lotUnitCost}</span></p>
                  <span className="text-xs text-muted-foreground ml-auto">→ verrà usato come Prezzo di Acquisto</span>
                </div>
              )}
            </div>
          )}
        </div>

        <div>
          <Label>Photo</Label>
          <label className="mt-2 flex flex-col items-center justify-center h-40 rounded-2xl border-2 border-dashed border-border bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors overflow-hidden">
            {imagePreview ? <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" /> : <div className="flex flex-col items-center gap-2 text-muted-foreground"><Upload className="h-8 w-8" /><span className="text-sm">Click to upload photo</span></div>}
            <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
          </label>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2 sm:col-span-2"><Label htmlFor="name">Item Name *</Label><Input id="name" placeholder="e.g. Vintage Watch" required value={form.name} onChange={(e) => updateField("name", e.target.value)} /></div>
          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select value={form.category} onValueChange={(v) => updateField("category", v)} required>
              <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="electronics">Electronics</SelectItem>
                <SelectItem value="clothing">Clothing</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="collectibles">Collectibles</SelectItem>
                <SelectItem value="vehicles">Vehicles</SelectItem>
                <SelectItem value="jewelry">Jewelry</SelectItem>
                <SelectItem value="tools">Tools</SelectItem>
                <SelectItem value="sports">Sports</SelectItem>
                <SelectItem value="books">Books</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2"><Label htmlFor="purchase_date">Purchase Date *</Label><Input id="purchase_date" type="date" required value={form.purchase_date} onChange={(e) => updateField("purchase_date", e.target.value)} /></div>

          <div className="space-y-2">
            <Label htmlFor="purchase_price">Purchase Price (€) *</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="purchase_price" type="number" step="0.01" min="0" placeholder="0.00" className="pl-9"
                required={!isLot || !lotUnitCost}
                value={isLot && lotUnitCost ? lotUnitCost : form.purchase_price}
                readOnly={isLot && !!lotUnitCost}
                onChange={(e) => !isLot && updateField("purchase_price", e.target.value)} />
            </div>
            {isLot && lotUnitCost && <p className="text-xs text-muted-foreground">Calcolato automaticamente dal lotto</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="selling_price">Selling Price (€)</Label>
            <div className="relative">
              <TrendingUp className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="selling_price" type="number" step="0.01" min="0" placeholder="0.00" className="pl-9"
                value={form.selling_price} onChange={(e) => updateField("selling_price", e.target.value)} />
            </div>
          </div>

          {estimatedProfit !== null && (
            <div className={`sm:col-span-2 flex items-center gap-4 rounded-xl px-4 py-3 border ${parseFloat(estimatedProfit) >= 0 ? "bg-green-500/10 border-green-500/20 text-green-600" : "bg-red-500/10 border-red-500/20 text-red-600"}`}>
              <TrendingUp className="h-5 w-5 shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium">Profitto stimato: <span className="font-bold">{parseFloat(estimatedProfit) >= 0 ? "+" : ""}€{estimatedProfit}</span></p>
                <p className="text-xs opacity-70">Margine: {parseFloat(profitMargin) >= 0 ? "+" : ""}{profitMargin}%</p>
              </div>
            </div>
          )}

          <div className="space-y-2 sm:col-span-2"><Label htmlFor="description">Description</Label><Textarea id="description" placeholder="Brief description of the item..." className="h-24" value={form.description} onChange={(e) => updateField("description", e.target.value)} /></div>
          <div className="space-y-2 sm:col-span-2"><Label htmlFor="notes">Notes</Label><Textarea id="notes" placeholder="Where you bought it, condition, etc..." className="h-20" value={form.notes} onChange={(e) => updateField("notes", e.target.value)} /></div>
        </div>

        <div className="flex gap-3 pt-4">
          <Link to="/inventory" className="flex-1"><Button variant="outline" className="w-full" type="button">Cancel</Button></Link>
          <Button type="submit" className="flex-1" disabled={createMutation.isPending}>
            {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Add Item
          </Button>
        </div>
      </form>
    </div>
  );
}
