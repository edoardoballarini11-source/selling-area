import { db } from '@/lib/store'
export const base44 = {
  entities: {
    Item: db.Item,
    BankTransaction: db.BankTransaction,
  },
  auth: {
    me: () => Promise.resolve({ role: 'admin' }),
    logout: () => { localStorage.clear(); window.location.href = '/'; },
    redirectToLogin: () => {},
  },
  integrations: {
    Core: {
      UploadFile: async ({ file }) => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve({ file_url: e.target.result });
          reader.readAsDataURL(file);
        });
      },
      SendEmail: (opts) => { console.log('Email (simulated):', opts); return Promise.resolve(); },
    }
  }
}
