import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from '@/components/layout/AppLayout';
import Dashboard from '@/pages/Dashboard';
import Inventory from '@/pages/Inventory';
import AddItem from '@/pages/AddItem';
import Settings from '@/pages/Settings';
import BankAccount from '@/pages/BankAccount';
import ProfitPredictor from '@/pages/ProfitPredictor';
import MarketTrends from '@/pages/MarketTrends';
import Shop from '@/pages/Shop';
import ProductDetail from '@/pages/ProductDetail';
import PendingOrders from '@/pages/PendingOrders';
import DiventaVenditore from '@/pages/DiventaVenditore';

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Shop />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/diventa-venditore" element={<DiventaVenditore />} />
            <Route path="/public/bank" element={<BankAccount />} />
            <Route path="/public/profit-predictor" element={<ProfitPredictor />} />
            <Route path="/public/market-trends" element={<MarketTrends />} />
            <Route path="/public/settings" element={<Settings />} />

            {/* Admin routes */}
            <Route element={<AppLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/add-item" element={<AddItem />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/bank" element={<BankAccount />} />
              <Route path="/profit-predictor" element={<ProfitPredictor />} />
              <Route path="/market-trends" element={<MarketTrends />} />
              <Route path="/pending-orders" element={<PendingOrders />} />
            </Route>
            <Route path="*" element={<PageNotFound />} />
          </Routes>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
